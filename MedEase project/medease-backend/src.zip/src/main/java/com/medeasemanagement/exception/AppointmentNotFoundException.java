package com.medeasemanagement.exception;

import org.springframework.stereotype.Component;

@Component
public class AppointmentNotFoundException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
